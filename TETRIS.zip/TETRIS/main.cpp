#include <QtWidgets>
#include <vector>
#include <iostream>

const int NUM_ROWS = 20;
const int NUM_COLS = 10;
const int BLOCK_SIZE = 30;

struct Block {
    int row;
    int col;
    QColor color;

    Block(int r, int c, const QColor& clr)
        : row(r), col(c), color(clr) {}
};

const std::vector<std::vector<Block>> shapes = {
    {{0, 0, Qt::red}, {0, 1, Qt::green}, {1, 0, Qt::blue}, {1, 1, Qt::yellow}},  // Kwadrat
    {{0, 0, Qt::green}, {1, 0, Qt::green}, {2, 0, Qt::green}, {3, 0, Qt::green}},  // Prosta linia
    {{0, 0, Qt::blue}, {1, 0, Qt::blue}, {2, 0, Qt::blue}, {2, 1, Qt::blue}},  // L
    {{0, 1, Qt::magenta}, {1, 0, Qt::magenta}, {1, 1, Qt::magenta}, {2, 0, Qt::magenta}},  // Z
};

class TetrisBoard : public QWidget {
public:
    TetrisBoard(QWidget* parent = nullptr)
        : QWidget(parent), currentShapeIndex(0), isFirstMove(true), score(0), bestScore(0) {
        setFixedSize(NUM_COLS * BLOCK_SIZE, NUM_ROWS * BLOCK_SIZE);
        setStyleSheet("background-color: white; border: 1px solid black;");

        grid = std::vector<std::vector<bool>>(NUM_ROWS, std::vector<bool>(NUM_COLS, false));

        timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &TetrisBoard::moveShapeDown);
        timer->start(500);

        // Inicjalizacja tablicy wyników
        scoreLabel = new QLabel(this);
        scoreLabel->setFont(QFont("Arial", 20, QFont::Bold));
        scoreLabel->move(10, 10);
        updateScoreLabel();

        // Inicjalizacja najlepszego wyniku
        bestScoreLabel = new QLabel(this);
        bestScoreLabel->setFont(QFont("Arial", 20, QFont::Bold));
        bestScoreLabel->move(width() - 10 - bestScoreLabel->width(), 10);
        updateBestScoreLabel();
    }

protected:
    void paintEvent(QPaintEvent* event) override {
        Q_UNUSED(event);

        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.setPen(QPen(Qt::black, 1));

        for (int row = 0; row < NUM_ROWS; ++row) {
            for (int col = 0; col < NUM_COLS; ++col) {
                QRect rect(col * BLOCK_SIZE, row * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
                if (grid[row][col]) {
                    painter.fillRect(rect, Qt::gray);
                } else {
                    painter.drawRect(rect);
                }
            }
        }

        if (!isFirstMove) {
            for (const auto& block : currentShape) {
                int x = block.col * BLOCK_SIZE;
                int y = block.row * BLOCK_SIZE;
                QRect rect(x, y, BLOCK_SIZE, BLOCK_SIZE);
                painter.fillRect(rect, block.color);
                painter.drawRect(rect);
            }
        }
    }

private:
    void generateNewShape() {
        int shapeCount = shapes.size();
        currentShapeIndex = QRandomGenerator::global()->bounded(shapeCount);
        currentShape = shapes[currentShapeIndex];

        int initialCol = (NUM_COLS - 2) / 2;
        for (auto& block : currentShape) {

            block.col += initialCol;
        }
    }

    void moveShapeLeft() {
        for (auto& block : currentShape) {
            if (block.col > 0 && !grid[block.row][block.col - 1])
                block.col--;
        }
    }

    void moveShapeRight() {
        for (auto& block : currentShape) {
            if (block.col < NUM_COLS - 1 && !grid[block.row][block.col + 1])
                block.col++;
        }
    }

    void moveShapeDown() {
        if (isFirstMove)
            return;

        for (auto& block : currentShape) {
            if (block.row < NUM_ROWS - 1 && !grid[block.row + 1][block.col])
                block.row++;
        }

        if (checkCollision()) {
            for (const auto& block : currentShape) {
                int row = block.row;
                int col = block.col;
                grid[row][col] = true;
            }

            removeCompletedLines();

            if (checkGameOver()) {
                endGame();
                return;
            }

            generateNewShape();
        }

        update();
    }

    void rotateShape() {
        int centerX = 0;
        int centerY = 0;
        for (auto& block : currentShape) {
            centerX += block.col;
            centerY += block.row;
        }
        centerX /= currentShape.size();
        centerY /= currentShape.size();

        for (auto& block : currentShape) {
            int relativeX = block.col - centerX;
            int relativeY = block.row - centerY;
            block.col = centerX - relativeY;
            block.row = centerY + relativeX;
        }

        int maxCol = 0;
        for (const auto& block : currentShape) {
            if (block.col > maxCol)
                maxCol = block.col;
        }

        int minCol = NUM_COLS - 1;
        for (const auto& block : currentShape) {
            if (block.col < minCol)
                minCol = block.col;
        }

        if (maxCol >= NUM_COLS)
            moveShapeLeft();
        else if (minCol < 0)
            moveShapeRight();
    }

    void keyPressEvent(QKeyEvent* event) override {
        if (isFirstMove) {
            generateNewShape();
            isFirstMove = false;
        }

        switch (event->key()) {
        case Qt::Key_Left:
            moveShapeLeft();
            break;
        case Qt::Key_Right:
            moveShapeRight();
            break;
        case Qt::Key_Down:
            moveShapeDown();
            break;
        case Qt::Key_Up:
            rotateShape();
            break;
        default:
            QWidget::keyPressEvent(event);
        }
    }

    bool checkCollision() {
        for (const auto& block : currentShape) {
            int row = block.row;
            int col = block.col;
            if (row >= NUM_ROWS - 1 || grid[row + 1][col])
                return true;
        }
        return false;
    }

    void removeCompletedLines() {
        std::vector<int> completedLines;
        for (int row = 0; row < NUM_ROWS; ++row) {
            bool isLineCompleted = true;
            for (int col = 0; col < NUM_COLS; ++col) {
                if (!grid[row][col]) {
                    isLineCompleted = false;
                    break;
                }
            }

            if (isLineCompleted)
                completedLines.push_back(row);
        }

        int numCompletedLines = completedLines.size();
        if (numCompletedLines > 0) {
            score += numCompletedLines * 100;
            if (score > bestScore)
                bestScore = score;
            updateScoreLabel();
            updateBestScoreLabel();
        }

        for (const auto& line : completedLines) {
            for (int col = 0; col < NUM_COLS; ++col) {
                grid[line][col] = false;
            }

            for (int row = line; row > 0; --row) {
                for (int col = 0; col < NUM_COLS; ++col) {
                    grid[row][col] = grid[row - 1][col];
                }
            }
        }
    }

    bool checkGameOver() {
        for (int col = 0; col < NUM_COLS; ++col) {
            if (grid[0][col])
                return true;
        }
        return false;
    }

    void endGame() {
        timer->stop();
        QMessageBox::information(this, "Game Over", "Game Over! Your score: " + QString::number(score));
        score = 0;
        updateScoreLabel();
        grid = std::vector<std::vector<bool>>(NUM_ROWS, std::vector<bool>(NUM_COLS, false));
        update();
        generateNewShape();
        isFirstMove = true;
        timer->start();
    }

    void updateScoreLabel() {
        scoreLabel->setText("Score: " + QString::number(score));
    }

    void updateBestScoreLabel() {
        bestScoreLabel->setText("Best: " + QString::number(bestScore));
    }

private:
    std::vector<std::vector<bool>> grid;
    std::vector<Block> currentShape;
    int currentShapeIndex;
    bool isFirstMove;
    int score;
    int bestScore;

    QTimer* timer;
    QLabel* scoreLabel;
    QLabel* bestScoreLabel;
};

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);

    TetrisBoard board;
    board.show();

    return app.exec();
}
